package courses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursesTopicsTextbooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursesTopicsTextbooksApplication.class, args);
	}
}
